<?php

include 'Conexion.php';
$nombre = $_POST['nombre'];
$apellido = $_POST['apellido'];
$correo = $_POST['correo'];
$contrasena = $_POST['contrasena'];
$telefono = $_POST['telefono'];

$sql=mysqli_query($conn,"INSERT INTO usuarios (id, nombre, apellido, correo, contrasena,telefono)
values (0, '$nombre','$apellido', '$correo', '$contrasena','$telefono');");

if($conn){
    header("location:/Actividad/index.html");
}else{
    mysqli_close($conn);

}

?>





