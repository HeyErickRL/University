<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="/Actividad/Peliculas/EstiloPeliculas2.css">
    <link rel="stylesheet" href="/Actividad/templates/navbar.css">
    <title>Favoritos</title>
</head>
<body>
<header class="header">
    <div class="logo">
      <img src="/Actividad/pelimarket.png" alt="">
  </div>
  <nav>
    <ul class="nav-links">
      <li><a href="/Actividad/Peliculas/Productos.php">Peliculas</a></li>
      <li><a href="/Actividad/Peliculas/guardar_favoritos.php"></a></li>
    </ul>
  </nav>
  <a class="btn" href="/Actividad/Peliculas/carrito/mostrar_carrito.php"><button>Carrito</button></a>
  </header>
  <body>
  <br><br><br><br>
  <p class="txt">Has comprado de manera exitosa las peliculas</p>
<p class="txt">Gracias por comprar con nosotros.</p>

</body>